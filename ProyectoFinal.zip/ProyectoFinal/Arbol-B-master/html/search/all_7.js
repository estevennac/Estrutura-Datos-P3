var searchData=
[
  ['pagina_0',['Pagina',['../class_pagina.html',1,'']]],
  ['pdf_1',['PDF',['../class_p_d_f.html',1,'']]]
];
