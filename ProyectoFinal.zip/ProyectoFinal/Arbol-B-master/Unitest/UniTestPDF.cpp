/**************************
 * Headers
 **************************/

#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <complex>
#include <cmath>
#include "pdf.cpp"
#include "metrics.cpp"
#include "Generar.h"

//UniTest PDF


int main(){
	  PDF pdf;
	  pdf.setFont(PDF::HELVETICA_BOLD,30);
	  pdf.showTextXY("Arbol B",210,746);  
	  pdf.setFont(PDF::TIMES,16);
	  pdf.showTextXY("Prueba UniTest",45,710);  
	  
	  string fileName = "UniTestPDF.pdf";
	  
	  
      string errMsg = "No se pudo crear el archivo.";

      if(!pdf.writeToFile(fileName, errMsg))
      {
         cout << errMsg << endl;
      }
      else
      {
         cout << "(Archivo  PDF creado correctamente)" << endl;
      }

      cout << endl;

   return 0;
}