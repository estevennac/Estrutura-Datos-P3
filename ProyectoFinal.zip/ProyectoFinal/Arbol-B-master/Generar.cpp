/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION
INGENIERIA DE SOFTWARE             
	AUTORES:
		Johan Romo
		Cristhopher Villamarin
		Sebastian Torres
                Jeanhela Nazate
                Milena Maldonado
                Shared Tinoco
		Brandon Masacela
		Juan Reyes
        GRUPOS: 7 - 10 - 11 - 14
        FECHA DE CREACION:        Viernes, 1 de julio de 2022 7:34:00 p. m. 	
	FECHA DE MODIFICACION:    Martes, 19 de junio de 2022 4:58:00 p. m.
        PROPOSITO: Proyecto Segundo Parcial - Arboles B
*/

#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <complex>
#include <cmath>
#include "pdf.cpp"
#include "metrics.cpp"
#include "Generar.h"

using std::complex;
using std::cout;
using std::endl;
using std::ifstream;
using std::ios;
using std::ostringstream;

Generar::Generar()
{
}

Generar::~Generar()
{
}

void Generar::generarPDF(string nombre)
{
    
    PDF p;
    p.setFont(PDF::HELVETICA_BOLD,30);
	p.showTextXY("ARBOL B",230,746);  
	p.setFont(PDF::HELVETICA,10);
	p.showTextXY("Grupos 7",50,699);
	p.showTextXY("Brandon Masacela, Juan Reyes",50,679);
	p.showTextXY("Grupos 10",350,699);
	p.showTextXY("Shared Tinoco, Sebastian Torres",350,679);
	p.showTextXY("Grupos 11",50,649);
	p.showTextXY("Johan Romo, Cristhoper Villamarin",50,629);
	p.showTextXY("Grupos 14",350,649);
	p.showTextXY("Jeanhela Nazate, Milena Maldonado",350,629);
    p.setFont(PDF::HELVETICA, 12);
    p.showTextXY("NUMEROS INGRESADOS:",50,546);
    string linea, texto;
    int x=50;
    ifstream original("prueba.txt");
    while (getline(original, linea))
    {
        p.showTextXY(linea,x,516);
        x+=50;
    }
    original.close();
	string errMsg;

    if (!p.writeToFile(nombre, errMsg))
    {
        cout << errMsg << endl;
    }
    else
    {
        cout << "(File Successfully Written)" << endl;
    }

    cout << endl;
}