/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION
INGENIERIA DE SOFTWARE             
	AUTORES:
		Johan Romo
		Cristhopher Villamarin
		Sebastian Torres
                Jeanhela Nazate
                Milena Maldonado
                Shared Tinoco
		Brandon Masacela
		Juan Reyes
        GRUPOS: 7 - 10 - 11 - 14
        FECHA DE CREACION:        Viernes, 1 de julio de 2022 7:34:00 p. m. 	
	FECHA DE MODIFICACION:    Martes, 19 de junio de 2022 4:58:00 p. m.
        PROPOSITO: Proyecto Segundo Parcial - Arboles B
*/

#ifndef _PDF_H_
#  define _PDF_H_

#  include <string>
#  include <vector>

   using std::string;
   using std::vector;

   // ---------------------------------
   // Image-Related Types
   // ---------------------------------

   struct RGB
   {
      unsigned char mRed;
      unsigned char mGreen;
      unsigned char mBlue;
   };

   typedef vector<RGB>      ImageRow;
   typedef vector<ImageRow> Image;

   struct ImageInfo
   {
      int    mObjectID;
      string mName;
      int    mWidth;
      int    mHeight;

      ImageInfo(
         int           objectID,
         const string &name,
         int           width,
         int           height
      )  :
         mObjectID(objectID), mName(name), mWidth(width), mHeight(height)
      {
      }
   };

   struct ImageEntry
   {
      Image     mImage;
      ImageInfo mInfo;

      ImageEntry(
         const Image     &image,
         const ImageInfo &info
      )  :
         mImage(image), mInfo(info)
      {
      }
   };

   // ---------------------------------
   // An x, y coordinate point
   // ---------------------------------

   struct XY
   {
      int mX;
      int mY;

      XY(int x, int y) : mX(x), mY(y) {}
   };

   // ---------------------------------
   // PDF
   // ---------------------------------

   class PDF
   {
      public:

         enum Font
         {
            NONE,
            COURIER,
            COURIER_BOLD,
            COURIER_OBLIQUE,
            COURIER_BOLD_OBLIQUE,
            HELVETICA,
            HELVETICA_BOLD,
            HELVETICA_OBLIQUE,
            HELVETICA_BOLD_OBLIQUE,
            SYMBOL,
            TIMES,
            TIMES_BOLD,
            TIMES_ITALIC,
            TIMES_BOLD_ITALIC,
            ZAPF_DINGBATS
         };

         enum { DEFAULT_WIDTH = 612, DEFAULT_HEIGHT = 792 };

         PDF();
         PDF(int width, int height);

         int getWidth()  const;
         int getHeight() const;

         void newPage();

         string toString();
         bool   writeToFile(const string &fileName, string &errMsg);

         ImageInfo processImage(const Image &theImage);

         void showImage(
            const ImageInfo &info, int x, int y, double xScale, double yScale
         );

         void showImage(
            const ImageInfo &info, int x, int y, double scale
         );

         void showImage(
            const ImageInfo &info, int x, int y
         );

         static int stringWidth(
            Font currentFont, int currentSize, const string &text
         );

         int stringWidth(const string &text);

         void setFont(Font theFont, int size);
         void showTextXY(const string &text, int x, int y);
         void rightJustifyTextXY(const string &text, int x, int y);

         vector<string> wrapText(
            const string &text, int maxWidth, bool rightJustify
         );

         void setLineWidth(int value);
         void drawLine(int x0, int y0, int x1, int y1);
         void drawLine(const vector<XY> &points);

         void drawRect(int x, int y, int width, int height);
         void fillRect(int x, int y, int width, int height);

         void drawPolygon(const vector<XY> &points);
         void fillPolygon(const vector<XY> &points);

         void drawEllipse(int xCenter, int yCenter, int xRadius, int yRadius);
         void fillEllipse(int xCenter, int yCenter, int xRadius, int yRadius);

         void drawCircle(int xCenter, int yCenter, int radius);
         void fillCircle(int xCenter, int yCenter, int radius);

         void setLineColor(
            unsigned char red, unsigned char green, unsigned char blue
         );

         void setFillColor(
            unsigned char red, unsigned char green, unsigned char blue
         );

         static const string FONTS[];
         static const int    N_FONTS;

      private:

         int mWidth;
         int mHeight;

         vector<string>     mPageContents;
         string             mCurrentPageContents;
         vector<ImageEntry> mEntries;

         Font mCurrentFont;
         int  mCurrentFontSize;
   };

#endif
