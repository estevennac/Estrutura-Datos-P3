/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION
INGENIERIA DE SOFTWARE             
	AUTORES:
		Johan Romo
		Cristhopher Villamarin
		Sebastian Torres
                Jeanhela Nazate
                Milena Maldonado
                Shared Tinoco
		Brandon Masacela
		Juan Reyes
        GRUPOS: 7 - 10 - 11 - 14
        FECHA DE CREACION:        Viernes, 1 de julio de 2022 7:34:00 p. m. 	
	FECHA DE MODIFICACION:    Martes, 19 de junio de 2022 4:58:00 p. m.
        PROPOSITO: Proyecto Segundo Parcial - Arboles B
*/

#include "Complemento.h"
#define TECLA_ARRIBA 72
#define TECLA_ABAJO 80
#define ENTER 13
#pragma once
Complemento::Complemento() {
	
}
void Complemento::gotoxy(int x,int y){
   HANDLE hCon;
	hCon = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD dwPos;
	dwPos.X = x;
	dwPos.Y = y;
	
	SetConsoleCursorPosition(hCon, dwPos);
   }
int Complemento::menu(const char *titulo, const char *opciones[], int n){
	 int opcionSeleccionada = 1;
   int tecla;
   bool repite = true;

   do {
      system("cls");
      gotoxy(5, 3 + opcionSeleccionada); cout << "==>";

      // Imprime el título
      gotoxy(15, 2); cout << titulo;

      // Imprime las opciones
      for (int i = 0; i < n; i++) {
         gotoxy(10, 4 + i); cout << i + 1 << ") " << opciones[i];
      }

      do {
         tecla = getch();
      } while (tecla != TECLA_ARRIBA && tecla != TECLA_ABAJO && tecla != ENTER);

      switch (tecla) {
         case TECLA_ARRIBA:
            opcionSeleccionada--;

            if (opcionSeleccionada < 1) {
               opcionSeleccionada = n;
            }
            break;

         case TECLA_ABAJO:
            opcionSeleccionada++;

            if (opcionSeleccionada > n) {
               opcionSeleccionada = 1;
            }
            break;

         case ENTER:
            repite = false;
            break;
      }

   } while (repite);


   return opcionSeleccionada;
}